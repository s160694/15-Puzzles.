﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace PuzzleDLL
{
    public class PuzzleDll
    {

        public void PrintSolution (IEnumerable<int> puzzle)
        {

            List<int> puzzleList = puzzle.ToList();

            if (Node.CheckIfSolveable(puzzleList))
            {

                Node root = new Node(puzzleList);
                List<Node> solution = BreadthFirstSearch.Search(root);

                for (int idx = 0; idx < solution.Count; idx++)
                {
                    Console.WriteLine(string.Format("--------------"));
                    solution[idx].PrintData();
                }

                if (!solution.Any())
                {
                    Console.WriteLine("Cannot find the path");
                }

            }
            else
            {
                Console.WriteLine("Combination is unsolveable");
            }

            Console.Read();

        }

    }
}
