﻿using System;
using System.Collections.Generic;

namespace PUZZLES
{

    internal class Node
    {

        #region Definitions

        public const int MATRIX_DIMENSION = 3;

        #endregion

        #region Constructors

        public Node(List<int> data)
        {
            this.data = SetData(data);
        }

        #endregion

        #region Operations

        public static bool CheckIfSolveable(List<int> data)
        {

            List<int> localData = new List<int>(data);

            List<int> dataWithoutBlankCell = RemoveEmptyCell(localData);
            int numberOfInversrions = 0;

            for (int idx = 0; idx < dataWithoutBlankCell.Count - 1; idx++)
            {

                for (int idx2 = idx; idx2 < dataWithoutBlankCell.Count; idx2++)
                {

                    if (dataWithoutBlankCell[idx] > dataWithoutBlankCell[idx2])
                    {
                        numberOfInversrions++;
                    }

                }

            }

            return numberOfInversrions % 2 == 0;

        }

        public bool IsSame(List<int> data)
        {

            for (int idx = 0; idx < data.Count; idx++)
            {
                if (data[idx] != this.data[idx])
                {
                    return false;
                }
            }

            return true;

        }

        public bool IsSolved()
        {

            for (int idx = 0; idx < this.data.Count - 1; idx++)
            {

                if (this.data[idx] != idx + 1)
                {
                    return false;
                }

            }

            return true;

        }

        public void ExecuteMove()
        {

            SetEmptyCellIdx();

            MoveRight(this.data, this.emptyCellIdx);
            MoveLeft(this.data, this.emptyCellIdx);
            MoveUp(this.data, this.emptyCellIdx);
            MoveDown(this.data, this.emptyCellIdx);

        }

        private void SetEmptyCellIdx()
        {

            for (int idx = 0; idx < this.data.Count; idx++)
            {
                if (this.data[idx] == 0)
                {
                    this.emptyCellIdx = idx;
                }
            }

        }

        public void MoveDown(List<int> data, int emptyCellIdx)
        {

            if (emptyCellIdx + MATRIX_DIMENSION < data.Count)
            {

                List<int> newPuzzle = new List<int>(data);
                int downNumberToSwap = data[emptyCellIdx + MATRIX_DIMENSION];
                newPuzzle[emptyCellIdx + MATRIX_DIMENSION] = newPuzzle[emptyCellIdx];
                newPuzzle[this.emptyCellIdx] = downNumberToSwap;

                Node child = new Node(newPuzzle);
                children.Add(child);
                child.parent = this;

            }

        }

        public void MoveLeft(List<int> data, int emptyCellIdx)
        {

            if (emptyCellIdx % MATRIX_DIMENSION > 0)
            {

                List<int> newPuzzle = new List<int>(data);
                int leftNumberToSwap = data[emptyCellIdx - 1];
                newPuzzle[emptyCellIdx - 1] = newPuzzle[emptyCellIdx];
                newPuzzle[this.emptyCellIdx] = leftNumberToSwap;

                Node child = new Node(newPuzzle);
                children.Add(child);
                child.parent = this;

            }

        }

        public void MoveRight(List<int> data, int emptyCellIdx)
        {

            if (emptyCellIdx % MATRIX_DIMENSION < MATRIX_DIMENSION - 1)
            {

                List<int> newPuzzle = new List<int>(data);
                int rightNumberToSwap = data[emptyCellIdx + 1];
                newPuzzle[emptyCellIdx + 1] = newPuzzle[emptyCellIdx];
                newPuzzle[this.emptyCellIdx] = rightNumberToSwap;

                Node child = new Node(newPuzzle);
                children.Add(child);
                child.parent = this;

            }

        }

        public void MoveUp(List<int> data, int emptyCellIdx)
        {

            if (emptyCellIdx - MATRIX_DIMENSION >= 0)
            {

                List<int> newPuzzle = new List<int>(data);
                int upperNumberToSwap = data[emptyCellIdx - MATRIX_DIMENSION];
                newPuzzle[emptyCellIdx - MATRIX_DIMENSION] = newPuzzle[emptyCellIdx];
                newPuzzle[this.emptyCellIdx] = upperNumberToSwap;

                Node child = new Node(newPuzzle);
                children.Add(child);
                child.parent = this;

            }

        }

        public void PrintData()
        {

            Console.WriteLine();

            int counter = 0;

            for (int idx = 0; idx < MATRIX_DIMENSION; idx++)
            {

                for (int idx2 = 0; idx2 < MATRIX_DIMENSION; idx2++)
                {
                    Console.Write(this.data[counter] + " ");
                    counter++;
                }

                Console.WriteLine();

            }

        }

        private static List<int> RemoveEmptyCell(List<int> data)
        {

            // empty cell is represented by '0'
            bool emptyCellRemoved = data.Remove(0);

            if (emptyCellRemoved == false)
            {
                throw new ArgumentException("Invalid data. Blank cell is missing!");
            }

            return data;

        }

        private List<int> SetData(List<int> data)
        {

            List<int> res = new List<int>();

            for (int idx = 0; idx < data.Count; idx++)
            {
                res.Add(data[idx]);
            }

            return res;

        }

        #endregion

        #region Properties

        public List<Node> Children
        {
            get { return this.children; }
        }

        public List<int> Data
        {
            get { return this.data; }
        }

        public Node Parent
        {
            get { return this.parent; }
        }

        #endregion

        #region Data members

        private List<int> data;
        private Node parent;
        private List<Node> children = new List<Node>();
        private int emptyCellIdx;

        #endregion

    }

}
