﻿using System;
using System.Collections.Generic;

namespace PUZZLES
{

    internal static class BreadthFirstSearch
    {

        #region Operations

        public static List<Node> Search(Node root)
        {

            List<Node> solutionPath = new List<Node>();
            List<Node> unvisited = new List<Node>();
            List<Node> visited = new List<Node>();

            unvisited.Add(root);
            bool foundSolutionPath = false;

            while (unvisited.Count > 0 && !foundSolutionPath)
            {

                Node actualNode = unvisited[0];
                visited.Add(actualNode);
                unvisited.RemoveAt(0);

                actualNode.ExecuteMove();

                for (int idx = 0; idx < actualNode.Children.Count; idx++)
                {

                    Node actualChild = actualNode.Children[idx];
                    foundSolutionPath = actualChild.IsSolved();

                    if (foundSolutionPath)
                    {
                        Console.WriteLine("Found a path!");
                        PathTrace(solutionPath, actualChild);
                        break;
                    }

                    if (!BreadthFirstSearch.Contains(unvisited, actualChild) && 
                        !BreadthFirstSearch.Contains(visited, actualChild))
                    {
                        unvisited.Add(actualChild);
                    }

                }

            }

            return solutionPath;

        }

        private static bool Contains(List<Node> listOfNodes, Node singleNode)
        {

            for (int idx = 0; idx < listOfNodes.Count; idx++)
            {
                if (listOfNodes[idx].IsSame(singleNode.Data))
                {
                    return true;
                }
            }

            return false;

        }

        private static void PathTrace(List<Node> path, Node node)
        {

            Console.WriteLine("Tracing ...");

            Node actualNode = node;
            path.Add(actualNode);

            while (actualNode.Parent != null)
            {
                actualNode = actualNode.Parent;
                path.Add(actualNode);
            }

        }

        #endregion

    }

}
