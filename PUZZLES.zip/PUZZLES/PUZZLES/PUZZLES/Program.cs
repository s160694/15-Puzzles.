﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace PUZZLES
{
    class Program
    {

        static void Main(string[] args)
        {

            //List<int> puzzle = new List<int>()
            //{
            //    1, 2, 4,
            //    3, 0, 5,
            //    7, 6, 8
            //};

            List<int> puzzle = new List<int>()
            {
                6, 4, 2,
                7, 1, 5,
                0, 8, 3
            };

            if (Node.CheckIfSolveable(puzzle))
            {

                Node root = new Node(puzzle);
                List<Node> solution = BreadthFirstSearch.Search(root);

                for (int idx = 0; idx < solution.Count; idx++)
                {
                    Console.WriteLine(string.Format("--------------"));
                    solution[idx].PrintData();
                }

                if (!solution.Any())
                {
                    Console.WriteLine("Cannot find the path");
                }

            }
            else
            {
                Console.WriteLine("Combination is unsolveable");
            }

            Console.Read();

        }

    }
}
